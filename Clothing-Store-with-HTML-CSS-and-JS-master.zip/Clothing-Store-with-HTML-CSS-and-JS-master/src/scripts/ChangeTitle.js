const baseURL = "http://127.0.0.1:5500/src/titles/"

function changeLinktoShirts(){
    console.log("working");
    var frame = document.getElementById("products-frame");
    frame.src = `${baseURL}Shirts.html`
}
function changeLinktoPants(){
    console.log("working");
    var frame = document.getElementById("products-frame");
    frame.src = `${baseURL}Pants.html`
}
function changeLinktoSummerCollections(){
    console.log("working");
    var frame = document.getElementById("products-frame");
    frame.src = `${baseURL}SummerCollections.html`
}
function changeLinktoWinterCollections(){
    console.log("working");
    var frame = document.getElementById("products-frame");
    frame.src = `${baseURL}WinterCollections.html`
}
function changeLinktoWatches(){
    console.log("working");
    var frame = document.getElementById("products-frame");
    frame.src = `${baseURL}Watches.html`
}
function changeLinktoSunGlasses(){
    console.log("working");
    var frame = document.getElementById("products-frame");
    frame.src = `${baseURL}SunGlasses.html`
}